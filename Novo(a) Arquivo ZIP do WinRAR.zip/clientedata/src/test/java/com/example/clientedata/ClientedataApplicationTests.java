package com.example.clientedata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientedataApplicationTests {

	@Test
	void contextLoads() {
	}

}
