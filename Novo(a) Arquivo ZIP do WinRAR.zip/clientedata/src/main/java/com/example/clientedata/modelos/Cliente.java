package com.example.clientedata.modelos;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import org.hibernate.validator.constraints.br.CPF;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "clientes")
public class Cliente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "cliente_id", nullable = false)
    private Integer clienteId;

    @NotBlank(message = "O campo 'Nome completo' é obrigatório.")
    @Size(max = 255, message = "O campo 'Nome completo' deve conter no máximo 255 caracteres.")
    @Column(name = "nome_completo", nullable = false, length = 255)
    private String nomeCompleto;

    @NotBlank(message = "O campo 'CPF' é obrigatório.")
    @CPF(message = "Informe um CPF válido no formato 000.000.000-00.")
    @Column(name = "cpf", nullable = false, length = 14, unique = true)
    private String cpf;

    @NotBlank(message = "O campo 'Telefone' é obrigatório.")
    @Pattern(
            regexp = "\\(\\d{2}\\) \\d{5}-\\d{4}",
            message = "Informe um telefone válido no formato (00) 00000-0000."
    )
    @Column(name = "telefone", nullable = false, length = 15)
    private String telefone;

    @NotBlank(message = "O campo 'E-mail' é obrigatório.")
    @Size(max = 255, message = "O campo 'E-mail' deve conter no máximo 255 caracteres.")
    @Email(message = "Informe um e-mail válido no formato nome@dominio.com.")
    @Column(name = "email", nullable = false, length = 255)
    private String email;


}