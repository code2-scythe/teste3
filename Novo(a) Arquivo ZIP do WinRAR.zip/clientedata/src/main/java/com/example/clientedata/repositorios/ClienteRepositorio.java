package com.example.clientedata.repositorios;

import com.example.clientedata.modelos.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ClienteRepositorio extends JpaRepository<Cliente, Integer> {

    Optional<Cliente> findByNomeCompleto(String nomeCompleto);

    Optional<Cliente> findByCpf(String cpf);

    Optional<Cliente> findByTelefone(String telefone);

    Optional<Cliente> findByEmail(String email);

    @Query("SELECT COALESCE(MAX(c.clienteId), 0) + 1 FROM Cliente c")
    Long getMaxClienteId();

}