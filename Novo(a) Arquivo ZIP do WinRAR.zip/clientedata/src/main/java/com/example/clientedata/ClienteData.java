package com.example.clientedata;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.text.MaskFormatter;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.example.clientedata.modelos.Cliente;
import com.example.clientedata.repositorios.ClienteRepositorio;

@SpringBootApplication
public class ClienteData extends JDialog {
    private JPanel panelGeral;
    private JPanel panelCampos;
    private JLabel lblCodigo;
    private JTextField txtCodigo;
    private JLabel lblNomeCompleto;
    private JTextField txtNomeCompleto;
    private JLabel lblCpf;
    private JFormattedTextField txtCpf;
    private JLabel lblTelefone;
    private JFormattedTextField txtTelefone;
    private JLabel lblEmail;
    private JTextField txtEmail;
    private JScrollPane panelTabela;
    private JTable tblClientes;
    private JPanel panelBotoes;
    private JButton btnSalvar;
    private JButton btnRemover;
    private JButton btnEditar;
    private JButton btnCancelar;
    private JPanel panelPesquisar;
    private JComboBox cmbPesquisar;
    private JTextField txtPesquisar;
    private JButton btnPesquisar;

    private final ClienteRepositorio clienteRepositorio;
    private final Validator validator;

    public ClienteData(ClienteRepositorio clienteRepositorio) {
        this.clienteRepositorio = clienteRepositorio;

        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();

        setTitle("Cliente Data");
        setContentPane(panelGeral);
        setModal(true);

        try {
            MaskFormatter maskFormatterCPF = new MaskFormatter("###.###.###-##");
            maskFormatterCPF.setPlaceholderCharacter('_');
            txtCpf.setFormatterFactory(new DefaultFormatterFactory(maskFormatterCPF));

            MaskFormatter maskFormatterTelefone = new MaskFormatter("(##) #####-####");
            maskFormatterTelefone.setPlaceholderCharacter('_');
            txtTelefone.setFormatterFactory(new DefaultFormatterFactory(maskFormatterTelefone));
        } catch (Exception exception) {
            JOptionPane.showMessageDialog(null, "Não foi possível aplicar as máscaras.", "Erro de Formatação", JOptionPane.ERROR_MESSAGE);
        }

        carregarTabela();
        obterProximoCodigoCliente();

        btnSalvar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nomeCompleto = txtNomeCompleto.getText();
                String cpf = txtCpf.getText();
                String telefone = txtTelefone.getText();
                String email = txtEmail.getText();

                Cliente cliente = new Cliente(null, nomeCompleto, cpf, telefone, email);

                Set<ConstraintViolation<Cliente>> violations = validator.validate(cliente);

                if (!violations.isEmpty()) {
                    String mensagensErros = violations.stream()
                            .map(ConstraintViolation::getMessage)
                            .collect(Collectors.joining("\n"));

                    JOptionPane.showMessageDialog(null, mensagensErros, "Erro de Validação", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                try {
                    clienteRepositorio.save(cliente);

                    JOptionPane.showMessageDialog(null, "Cliente salvo com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);

                    carregarTabela();
                    limparCampos();
                    obterProximoCodigoCliente();
                } catch (Exception exception) {
                    JOptionPane.showMessageDialog(null, "Erro ao salvar os dados do cliente.", "Erro de Salvamento", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        btnRemover.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int linhaSelecionada = tblClientes.getSelectedRow();

                if (linhaSelecionada >= 0) {
                    try {
                        int clienteId = (int) tblClientes.getValueAt(linhaSelecionada, 0);
                        clienteRepositorio.deleteById(clienteId);

                        ((DefaultTableModel) tblClientes.getModel()).removeRow(linhaSelecionada);

                        carregarTabela();
                        limparCampos();

                        JOptionPane.showMessageDialog(null, "Cliente removido com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, "Erro ao remover o cliente.", "Erro de Remoção", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Selecione um cliente para remover.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
    }

    private void carregarTabela() {
        DefaultTableModel modeloTabela = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        modeloTabela.addColumn("Código");
        modeloTabela.addColumn("Nome Completo");
        modeloTabela.addColumn("CPF");
        modeloTabela.addColumn("Telefone");
        modeloTabela.addColumn("E-mail");

        try {
            List<Cliente> clientes = clienteRepositorio.findAll();

            for (Cliente cliente : clientes) {
                modeloTabela.addRow(new Object[]{
                        cliente.getClienteId(),
                        cliente.getNomeCompleto(),
                        cliente.getCpf(),
                        cliente.getTelefone(),
                        cliente.getEmail(),
                });
            }
        } catch (Exception exception) {
            JOptionPane.showMessageDialog(null, "Erro ao carregar os clientes.", "Erro de Carregamento", JOptionPane.ERROR_MESSAGE);
        }

        tblClientes.setModel(modeloTabela);
        tblClientes.getTableHeader().setReorderingAllowed(false);
    }

    private void obterProximoCodigoCliente() {
        Long proximoId = clienteRepositorio.getMaxClienteId();
        txtCodigo.setText(String.valueOf(proximoId));
    }

    private void limparCampos() {
        txtNomeCompleto.setText(null);
        txtCpf.setText(null);
        txtTelefone.setText(null);
        txtEmail.setText(null);
    }

    public static void main(String[] args) throws UnsupportedLookAndFeelException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());

        ApplicationContext context = SpringApplication.run(ClienteData.class, args);
        ClienteRepositorio clienteRepositorio = context.getBean(ClienteRepositorio.class);

        SwingUtilities.invokeLater(() -> {
            ClienteData dialog = new ClienteData(clienteRepositorio);
            dialog.pack();
            dialog.setLocationRelativeTo(null);
            dialog.setVisible(true);
            System.exit(0);
        });
    }

}